package com.cg.arsspringmvc.dao;


import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.swing.text.StyledEditorKit.BoldAction;

import org.springframework.stereotype.Repository;

import com.cg.arsspringmvc.dto.Airport;
import com.cg.arsspringmvc.dto.BookingInformation;
import com.cg.arsspringmvc.dto.FlightInformation;
import com.cg.arsspringmvc.dto.Users;

@Repository("arsDao")
public class ARSDaoImpl implements IARSDao
{
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public String getRole(String uname, String pass) 
	{
		String query = "SELECT b FROM Users b   WHERE b.userName = :USERNAME AND b.password = :PASSWORD " ;
		TypedQuery<Users> queryone = 
		entityManager.createQuery( query , Users.class);
		queryone.setParameter( "USERNAME" , uname );
		queryone.setParameter( "PASSWORD", pass );
		
		Users usr = queryone.getSingleResult();
		
		
		//System.out.println(usr.getRole());
		return usr.getRole();
	}

	@Override
	public HashMap<String, Airport> getAirportList() 
	{
		  TypedQuery<Airport> queryone = entityManager.createQuery(" FROM AIRPORT " , Airport.class);
	      List<Airport> airportList = queryone.getResultList();
	      
	      HashMap<String, Airport> arpList = new HashMap ();
	      
	      for (Airport airport : airportList) 
	      {
	    	  arpList.put( airport.getAbbreviation(), airport );
		  }
	      return arpList;
	}
	
	@Override
	public List<FlightInformation> showAllFlights() 
	{
		
		TypedQuery<FlightInformation> queryone = 
				entityManager.createQuery("FROM FlightInformation" , FlightInformation.class);
		List<FlightInformation> flightdata = queryone.getResultList();
		
		return flightdata;
	}

	/*
	 * Method only for Admin
	 */

	@Override
	public void addFlightInformation(FlightInformation flightInfo) 
	{
		entityManager.persist(flightInfo);		
	}

	@Override
	public void updateFlightInformation(FlightInformation updateflight) 
	{
		FlightInformation flightData =
				entityManager.find(FlightInformation.class, updateflight.getFlightno());
		
		flightData.setAirline(updateflight.getAirline());
		flightData.setDepArp(updateflight.getDepArp());
		flightData.setArrArp(updateflight.getArrArp());
		flightData.setDepTime(updateflight.getDepTime());
		flightData.setArrTime(updateflight.getArrTime());
		flightData.setDepDate(updateflight.getDepDate());
		flightData.setFirstSeats(updateflight.getFirstSeats());
		flightData.setFirstSeatFare(updateflight.getFirstSeatFare());
		flightData.setBussSeats(updateflight.getBussSeats());
		flightData.setBussSeatsFare(updateflight.getBussSeatsFare());
		
	}

	/*
	 * methods mainly for executive
	 */
	
	@Override
	public FlightInformation viewFlightDetail(int flightNo) 
	{
		String query = "SELECT b FROM FlightInformation b WHERE flightno = :FLIGHTNO" ;
		TypedQuery<FlightInformation> queryone = 
				entityManager.createQuery( query , FlightInformation.class);
		queryone.setParameter( "FLIGHTNO", flightNo );
		
		FlightInformation flightData = queryone.getSingleResult();
		
		return flightData;
	}

	@Override
	public List<BookingInformation> viewBookings(int flightNo) 
	{
		String query = "SELECT b FROM BOOKINGINFORMATION.b WHERE FLIGHTNO = :uFlightno";
		TypedQuery<BookingInformation> queryone = 
				entityManager.createQuery( query , BookingInformation.class);
		queryone.setParameter("uFlightno", flightNo);
		List<BookingInformation> bookingdata = queryone.getResultList();
		
		return bookingdata;
	}

	@Override
	public BookingInformation getBooking(int bookId) 
	{
		String query = "SELECT b FROM BOOKINGINFORMATION.b WHERE bookingid = :uBookingId " ;
		TypedQuery<BookingInformation> queryone = 
				entityManager.createQuery( query , BookingInformation.class);
		queryone.setParameter( "uBookingId", bookId );
		
		BookingInformation bookingData = queryone.getSingleResult();
		
		return bookingData;
	}
	
	/*
	 * methods mainly for customer
	 */

	@Override
	public List<FlightInformation> viewFlightOn(String depArp,
			String arrArp, Date date) 
	{
		
		java.sql.Date date1 = new java.sql.Date( date.getTime());
		
		
		String query =
			"SELECT b FROM FlightInformation b WHERE DEPARP = :DEP_ARP AND ARRARP = :ARR_ARP AND depDate =:DEP_DATE";
		TypedQuery<FlightInformation> queryone = 
				entityManager.createQuery( query , FlightInformation.class);
		queryone.setParameter("DEP_ARP", depArp);
		queryone.setParameter("ARR_ARP", arrArp);
		queryone.setParameter("DEP_DATE",date1);
		List<FlightInformation> availableFlights = queryone.getResultList();
		
		return availableFlights;
	}

	@Override
	public int addBookingInformation(BookingInformation bookingEntry) 
	{
		
		System.out.println("came in dao");
		int bookingID=0;
		
		int noOfTravellers =  bookingEntry.getNoOfAdult() + bookingEntry.getNoOfChildren() ;
		
		System.out.println("no of travellers " + noOfTravellers );
		
		boolean status = bookSeats( bookingEntry.getFlight().getFlightno() ,noOfTravellers, bookingEntry.getClassType() );
		
		System.out.println("status = " + status );
		
		if(status)
			{
				entityManager.persist(bookingEntry);
				bookingID = bookingEntry.getBookingId();
			}
		
		return bookingID;
	}

	@Override
	public void removeBooking(int bookId) 
	{
		BookingInformation bookingEntry = entityManager.find(BookingInformation.class, bookId);
		
		int noOfTravellers =  bookingEntry.getNoOfAdult() + bookingEntry.getNoOfChildren() ;
		
		releaseSeats( bookingEntry.getFlight().getFlightno() ,noOfTravellers, bookingEntry.getClassType() );
		
		entityManager.remove(bookingEntry);			
	}
	
/*
 * private  Methods 
 */
	
	private boolean bookSeats(int flightno , int seats ,  String classType )
	{
		
		System.out.println("booking seats now ");
		FlightInformation flight = entityManager.find(FlightInformation.class , flightno);
		
		System.out.println(flight);
		
		if(classType.equals("first"))
		{
			int currSeats = flight.getFirstSeats();
			
			if(currSeats >= seats)
			{
			   flight.setFirstSeats( currSeats-seats );
			   return true;
			}
			
				return false;
		}
		
		else if(classType.equals("business"))
		{
			int currSeats = flight.getBussSeats();
			
			if(currSeats >= seats)
			{
				flight.setBussSeats( currSeats-seats );
				return true;
			}
			
			return false;
		}
		
		return false;
	}
	
	private void releaseSeats(int flightno , int seats ,  String classType )
	{
		FlightInformation flight = entityManager.find(FlightInformation.class , flightno);
		
		if(classType.equals("first"))
		{
			int currSeats = flight.getFirstSeats();

			flight.setFirstSeats( currSeats+seats );
		
		}
		
		else if(classType.equals("business"))
		{
			   int currSeats = flight.getBussSeats();

			   flight.setFirstSeats( currSeats+seats );
			  
	    }
	

	}
}
