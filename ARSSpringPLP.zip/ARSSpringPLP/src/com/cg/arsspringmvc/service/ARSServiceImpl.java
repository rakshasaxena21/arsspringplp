package com.cg.arsspringmvc.service;


import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.arsspringmvc.dao.IARSDao;
import com.cg.arsspringmvc.dto.Airport;
import com.cg.arsspringmvc.dto.BookingInformation;
import com.cg.arsspringmvc.dto.FlightInformation;


@Service("arsService")
@Transactional
public class ARSServiceImpl implements IARSService {

	@Autowired
	IARSDao arsDao;
	
	@Override
	public String getRole(String uname, String pass)
	{
		return arsDao.getRole(uname, pass);
	}

	@Override
	public HashMap<String, Airport> getAirportList() 
	{
		return arsDao.getAirportList();
	}

	@Override
	public List<FlightInformation> showAllFlights() 
	{
		return arsDao.showAllFlights();
	}


	@Override
	public void addFlightInformation(FlightInformation flightInfo) 
	{
		arsDao.addFlightInformation(flightInfo);;	
	}

	@Override
	public void updateFlightInformation(FlightInformation updateflight) 
	{
		arsDao.updateFlightInformation(updateflight);
	}

	@Override
	public FlightInformation viewFlightDetail(int flightNo)
	{
		return arsDao.viewFlightDetail(flightNo);
	}

	@Override
	public List<BookingInformation> viewBookings(int flightNo) 
	{
		return arsDao.viewBookings(flightNo);
	}

	@Override
	public BookingInformation getBooking(int bookId) 
	{
		return arsDao.getBooking(bookId);
	}

	@Override
	public List<FlightInformation> viewFlightOn(String depArp,
			String arrArp, Date date) 
	{
		return arsDao.viewFlightOn(depArp, arrArp, date);
	}

	@Override
	public int addBookingInformation(BookingInformation bookingEntry) 
	{
		return arsDao.addBookingInformation(bookingEntry);
	}

	@Override
	public void removeBooking(int bookId) 
	{
		arsDao.removeBooking(bookId);
	}



}
