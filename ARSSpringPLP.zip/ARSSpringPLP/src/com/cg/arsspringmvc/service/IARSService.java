package com.cg.arsspringmvc.service;


import java.util.Date;
import java.util.HashMap;
import java.util.List;

import com.cg.arsspringmvc.dto.Airport;
import com.cg.arsspringmvc.dto.BookingInformation;
import com.cg.arsspringmvc.dto.FlightInformation;

public interface IARSService 
{
	public String getRole(String uname, String pass);
	public  HashMap<String, Airport> getAirportList();
	public List <FlightInformation> showAllFlights();
	
	
	/*
	 * methods mainly for admin
	 */
	public void addFlightInformation(FlightInformation flightInfo);
	public void updateFlightInformation(FlightInformation updateflight);
	

	/*
	 * methods mainly for executive
	 */
	public FlightInformation viewFlightDetail(int flightNo);
	public List<BookingInformation> viewBookings(int flightNo);
	public BookingInformation getBooking(int bookId);
	

	/*
	 * methods mainly for customer
	 */
	public List<FlightInformation> viewFlightOn(String depArp , String arrArp , Date date);
	public int addBookingInformation(BookingInformation bookingEntry);
	public void removeBooking(int bookId);
	
}
