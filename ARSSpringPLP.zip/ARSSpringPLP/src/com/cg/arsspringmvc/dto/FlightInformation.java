package com.cg.arsspringmvc.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.print.DocFlavor.STRING;

import org.jboss.ejb3.annotation.Clustered;

import com.cg.arsspringmvc.dto.Airport;



@Entity
@Table( name="FLIGHTINFORMATION" )
public class FlightInformation implements Serializable
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column( name="FLIGHTNO" )
	private int flightno ;
	@Column( name="AIRLINE" )
	private String airline ;
	
	@OneToOne( fetch=FetchType.LAZY )
	@JoinColumn( name="DEPARP" )
	private Airport depArp ;
	
	@OneToOne( fetch=FetchType.LAZY )
	@JoinColumn( name="ARRARP" )
    private Airport arrArp ;
    @Column( name="DEP_TIME" )
	private String depTime;
	@Column( name="ARR_TIME" )
	private String arrTime;
	@Column( name="DEP_DATE" )
	private Date depDate;
	@Column( name="FIRSTSEATS" )
    private int FirstSeats ;
	@Column( name="FIRSTSEATSFARE" )
    private double FirstSeatFare ;
	@Column( name="BUSSSEATS" )
    private int BussSeats ; 
	@Column( name="BUSSSEATSFARE" )
    private double BussSeatsFare ;
	
//	private Set<BookingInformation> bookingList;
//	
//	
//	public void setBookingList(Set<BookingInformation> bookingList) {
//		this.bookingList = bookingList;
//	}
//
//	@OneToMany(mappedBy="flightno", fetch=FetchType.LAZY) 
//	public Set<BookingInformation> getBookingList() {
//		return bookingList;
//	}
	
	public int getFlightno() {
		return flightno;
	}
	public void setFlightno(int flightno) {
		this.flightno = flightno;
	}
	public String getAirline() {
		return airline;
	}
	public void setAirline(String airline) {
		this.airline = airline;
	}
	public Airport getDepArp() {
		return depArp;
	}
	public void setDepArp(Airport depArp) {
		this.depArp = depArp;
	}
	public Airport getArrArp() {
		return arrArp;
	}
	public void setArrArp(Airport arrArp) {
		this.arrArp = arrArp;
	}
	public String getDepTime() {
		return depTime;
	}
	public void setDepTime(String depTime) {
		this.depTime = depTime;
	}
	public String getArrTime() {
		return arrTime;
	}
	public void setArrTime(String arrTime) {
		this.arrTime = arrTime;
	}
	public Date getDepDate() {
		return depDate;
	}
	public void setDepDate(Date depDate) {
		this.depDate = depDate;
	}
	public int getFirstSeats() {
		return FirstSeats;
	}
	public void setFirstSeats(int firstSeats) {
		FirstSeats = firstSeats;
	}
	public double getFirstSeatFare() {
		return FirstSeatFare;
	}
	public void setFirstSeatFare(double firstSeatFare) {
		FirstSeatFare = firstSeatFare;
	}
	public int getBussSeats() {
		return BussSeats;
	}
	public void setBussSeats(int bussSeats) {
		BussSeats = bussSeats;
	}
	public double getBussSeatsFare() {
		return BussSeatsFare;
	}
	public void setBussSeatsFare(double bussSeatsFare) {
		BussSeatsFare = bussSeatsFare;
	}
	@Override
	public String toString() {
		return "FlightInformation [flightno=" + flightno + ", airline="
				+ airline + ", depArp=" + depArp + ", arrArp=" + arrArp
				+ ", depTime=" + depTime + ", arrTime=" + arrTime
				+ ", depDate=" + depDate + ", FirstSeats=" + FirstSeats
				+ ", FirstSeatFare=" + FirstSeatFare + ", BussSeats="
				+ BussSeats + ", BussSeatsFare=" + BussSeatsFare + "]";
	}
	
	

}
