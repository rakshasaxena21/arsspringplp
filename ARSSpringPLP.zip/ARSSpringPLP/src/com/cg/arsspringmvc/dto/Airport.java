package com.cg.arsspringmvc.dto;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity( name="AIRPORT" )
@Table( name="AIRPORT" )
public class Airport implements Serializable
{

	/**
	 * This is Airport Class which will be responsible for the
	 * fetching Airport details
	 */
	private static final long serialVersionUID = 1L;
    
	@Column( name="AIRPORTNAME" )
	private String airportName;
	@Id
	@Column( name="ABBREVIATION" )
	private String abbreviation;
	@Column( name="LOCATIONCITY" )
	private String city;
	@Column( name="LOCATIONSTATE" )
	private String state;
	@Column( name="LOCATIONCOUNTRY" )
	private String country;
	
	
//	private Set<FlightInformation> flightList;
//	
//	
//	public Set<FlightInformation> getFlightList() {
//		return flightList;
//	}
//
//	
//	@OneToMany(mappedBy="abbreviation", fetch=FetchType.LAZY) 
//	public void setFlightList(Set<FlightInformation> flightList) {
//		this.flightList = flightList;
//	}

	public Airport() 
	{
	}

	
	
	public String getAirportName() {
		return airportName;
	}

	public void setAirportName(String airportName) {
		this.airportName = airportName;
	}

	public String getAbbreviation() {
		return abbreviation;
	}

	public void setAbbreviation(String abbreviation) {
		this.abbreviation = abbreviation;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	
}

