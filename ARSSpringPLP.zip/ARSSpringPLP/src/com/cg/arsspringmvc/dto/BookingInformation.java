package com.cg.arsspringmvc.dto;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.cg.arsspringmvc.dto.Airport;


@Entity( name="BOOKINGINFORMATION" )
@Table( name="BOOKINGINFORMATION" )
public class BookingInformation implements Serializable 
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column( name="BOOKINGID" )
	@SequenceGenerator( name="BOOKING_ID_SEQ" , sequenceName="BOOKING_ID_SEQ" )
	@GeneratedValue( strategy=GenerationType.SEQUENCE,generator="BOOKING_ID_SEQ")
	private int BookingId;
	@Column( name="CUSTOMEREMAIL" )
    private String custEmail ; 
	@Column( name="NO_OF_CHILDREN" )
    private int noOfChildren ;
	@Column( name="NO_OF_ADULTS" )
    private int noOfAdult ; 
	@Column( name="CLASSTYPE" )
    private String classType ;
	@Column( name="TOTALFARE" )
    private double  totalFare ;
	@Column( name="CREDITCARD" )
	private String creditCard ;
	
	@OneToOne( fetch=FetchType.EAGER )
	@JoinColumn( name="FLIGHT" )
    private FlightInformation flight;
	
	public BookingInformation() 
	{
	}

	public int getBookingId() {
		return BookingId;
	}

	public void setBookingId(int bookingId) {
		BookingId = bookingId;
	}

	public String getCustEmail() {
		return custEmail;
	}

	public void setCustEmail(String custEmail) {
		this.custEmail = custEmail;
	}

	public int getNoOfChildren() {
		return noOfChildren;
	}

	public void setNoOfChildren(int noOfChildren) {
		this.noOfChildren = noOfChildren;
	}

	public int getNoOfAdult() {
		return noOfAdult;
	}

	public void setNoOfAdult(int noOfAdult) {
		this.noOfAdult = noOfAdult;
	}

	public String getClassType() {
		return classType;
	}

	public void setClassType(String classType) {
		this.classType = classType;
	}

	public double getTotalFare() {
		return totalFare;
	}

	public void setTotalFare(double totalFare) {
		this.totalFare = totalFare;
	}

	public String getCreditCard() {
		return creditCard;
	}

	public void setCreditCard(String creditCard) {
		this.creditCard = creditCard;
	}

	public FlightInformation getFlight() {
		return flight;
	}

	public void setFlight(FlightInformation flight) {
		this.flight = flight;
	}

	@Override
	public String toString() {
		return "BookingInformation [BookingId=" + BookingId + ", custEmail="
				+ custEmail + ", noOfChildren=" + noOfChildren + ", noOfAdult="
				+ noOfAdult + ", classType=" + classType + ", totalFare="
				+ totalFare + ", creditCard=" + creditCard + ", flight=" + flight + "]";
	}

	
	
}
