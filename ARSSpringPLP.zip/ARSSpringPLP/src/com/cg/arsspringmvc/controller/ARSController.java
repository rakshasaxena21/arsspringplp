package com.cg.arsspringmvc.controller;

import java.sql.Date;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletException;

import org.jboss.security.auth.container.modules.AllFailureServerAuthModule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.arsspringmvc.dto.Airport;
import com.cg.arsspringmvc.dto.BookingInformation;
import com.cg.arsspringmvc.dto.FlightInformation;
import com.cg.arsspringmvc.service.IARSService;


@Controller
public class ARSController 
{
	
	
	
	@Autowired
	IARSService arsService;
	
	HashMap<String, Airport> allAirport=null;
	
	

	@RequestMapping(value = "mainPageProcess.do")
	public String processMainPage(  Map<String,Object> model )
	{
		allAirport = arsService.getAirportList();
				
		Set<String> arpAbbSet = allAirport.keySet();
        ArrayList<String> airportList = new ArrayList(arpAbbSet);
        FlightInformation flight =  new FlightInformation();
        //System.out.println(airportList);
		model.put( "arpList" , airportList );
		model.put( "flight" , flight);
	
		return "mainPage";
	}
	
	
	/**
	 *Login Admin or Executive 
	 * @param uName
	 * @param pass
	 * @return String
	 * @throws ARSException
	 */
	
	@RequestMapping( value="/login.do" , method = RequestMethod.POST )
	public String login( @RequestParam("uname") String uName , @RequestParam("pass") String pass )
	{
		String retPage = null;
		
		String role = arsService.getRole(uName, pass);
		
		if( role.equals("") || role.equals(null) )
		  {
			retPage = "error";
		  }
		else if ( role.equals("Admin") )
		  {
			retPage = "Admin";
	      }
		else if ( role.equals("Executive") )
		  {
			retPage = "Executive";
		  }
		
		return retPage;
	}
	
	
	/**
	 * Display all flights
	 * @return ModelAndView
	 * @throws ARSException
	 */
	
	@RequestMapping( value="/showAllFlights.do" )
	public ModelAndView showAllFlights()
	{		
		
		List<FlightInformation> allFlights = arsService.showAllFlights();
		//System.out.println(allFlights);
		if(allFlights.isEmpty())
		{
			ModelAndView model = new ModelAndView("error");
			model.addObject("errMsg","NO DATA TO DISPLAY");
			return model;
		}
		
		return new ModelAndView( "showFlights", "flightData", allFlights );
	}
	
	
	/**
	 * Add a New Flight
	 * @param flightno
	 * @return string
	 * @throws ARSException
	 */
	@RequestMapping( value="addFlight.do" , method = RequestMethod.GET )
	public String addFlight( @ModelAttribute("flight") FlightInformation flightinfo )
	{
		System.out.println("heres the flight data  " + flightinfo);
		arsService.addFlightInformation(flightinfo);
		
		return "showAllFlights";
	}
	
	/**
	 * Retrieving Data for Flight updation
	 * @param flightno
	 * @param map
	 * @param flightInformation
	 * @return string
	 * @throws ARSException
	 */
	@RequestMapping( value="/update.do" )
	public String update( @RequestParam("flightId") int flightId , Map<String,Object> model 
			          , @ModelAttribute("flight") FlightInformation flight ) 
    {
		System.out.println("update" + flightId);
		flight = arsService.viewFlightDetail(flightId);
		
		Set<String> arpAbbSet = allAirport.keySet();
        ArrayList<String> airportList = new ArrayList(arpAbbSet);
		model.put( "flight" , flight );
		model.put( "arpList" , airportList );
		
		return "edit";
	}
	
	
	/**
	 * initiating flight updation
	 * @param flightinformation
	 * @return string
	 * @throws ARSException
	 */
	@RequestMapping(value = "executeUpdate.do" , method = RequestMethod.POST)
	public String updateData(@ModelAttribute("flight") FlightInformation flightData ,  BindingResult errors)
	{
		//System.out.println(flightData);
		arsService.updateFlightInformation(flightData);
		System.out.println("updated");
		return "redirect:/showAllFlights.do" ;
	}
	
	
	/**
	 * initiating add Flight Form
	 * @param Model
	 * @return string
	 * @throws ARSException
	 */
	@RequestMapping(value = "processAddFlight.do")
	public String processAddFlight(  Map<String,Object> model )
	{
		
		Set<String> arpAbbSet = allAirport.keySet();
        ArrayList<String> airportList = new ArrayList(arpAbbSet);
        FlightInformation flight =  new FlightInformation();
		model.put( "arpList" , airportList );
		model.put( "flight" , flight);
		return "addNewFlight";
	}
	

	/**
	 * initiating new Flight addittion
	 * @param flightinformation
	 * @return string
	 * @throws ARSException
	 */
	
	@RequestMapping(value = "addFlight.do" , method = RequestMethod.POST)
	public String AddFlight(  @RequestParam("depDate") String depDate , @RequestParam("arrArp") String arrArp ,@RequestParam("depArp") String depArp , @ModelAttribute("flight") FlightInformation flightData ,  BindingResult errors)
	{
		//System.out.println(flightData);
		
		SimpleDateFormat sdf1 = new SimpleDateFormat("mm-dd-yyyy");
		java.util.Date date=null;
		try {
			date = sdf1.parse(depDate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		java.sql.Date sqlStartDate = new java.sql.Date(date.getTime());  
		
		
		flightData.setArrArp(allAirport.get(arrArp));
		flightData.setDepArp(allAirport.get(depArp));
		flightData.setDepDate(sqlStartDate);
		arsService.addFlightInformation(flightData);
		return "redirect:/showAllFlights.do" ;
	}
	
	

	/**
	 * processing booking data
	 * @param trip
	 * @param retDate
	 * @param depArp
	 * @param depDate
	 * @param arrArp
	 * @param flightData
	 * @return String
	 * @throws ARSException
	 */
	
	@RequestMapping(value = "processBookingDetails.do" , method = RequestMethod.POST)
	public String processBooking( @RequestParam("trip") String trip , @RequestParam("arrDate") Date retDate ,@RequestParam("noOfAdult") int adult ,
			@RequestParam("noOfChildren")  int child , @RequestParam("depArp") String depArp ,  @RequestParam("depDate") Date depDate , @RequestParam("arrArp") String arrArp ,			
			@ModelAttribute("flight") FlightInformation flightData , BindingResult errors , Map<String,Object> model )
	{
		System.out.println("booking flight");
	    flightData.setArrArp(allAirport.get(arrArp));
	    flightData.setDepArp(allAirport.get(depArp));
	    flightData.setDepDate(depDate);
	    
		List<FlightInformation> upFlights = 
				arsService.viewFlightOn( flightData.getDepArp().getAbbreviation(), 
						flightData.getArrArp().getAbbreviation(), flightData.getDepDate() );
		
		
		System.out.println(upFlights);
		
		List<FlightInformation> downFlights=new ArrayList<>();
		
		if(trip.equals("round"))
		{
			downFlights = 
					arsService.viewFlightOn( flightData.getArrArp().getAbbreviation(),
							flightData.getDepArp().getAbbreviation(), retDate );
		}
		
		BookingInformation booking = new BookingInformation();
		booking.setNoOfChildren(child);
		booking.setNoOfAdult(adult);
		
		
		model.put( "booking",booking );
		model.put( "flight",flightData );
		model.put("upFlights",upFlights);
		model.put("trip",trip);
		model.put("adult",adult);
		model.put("children",child);
		
		if( downFlights.size() != 0 )
		{
			model.put("downFlights", downFlights);
		}
			
		System.out.println(downFlights);
		
		return "viewAvailableFlight" ;
	}
	
	
	
	/**
	 * book tickets
	 * @param trip
	 * @param retDate
	 * @param depArp
	 * @param depDate
	 * @param arrArp
	 * @param flightData
	 * @return String
	 * @throws ARSException
	 */
	
	@RequestMapping(value = "reserveFlight.do" , method = RequestMethod.POST)
	public String processBooking
	     ( @RequestParam("class") String classType , @RequestParam("upFlight") int upflight ,@RequestParam("downFlight") int downFlight ,@RequestParam("noOfAdult") int adult ,
	 			@RequestParam("noOfChildren")  int child , @ModelAttribute("booking") BookingInformation booking , @RequestParam("custEmail") String email , @RequestParam("creditCard") String creditCard
			, BindingResult errors , Map<String,Object> model )
	{
		
		System.out.println("********************************");
		System.out.println(classType);
		System.out.println(upflight);
		System.out.println(downFlight);
		System.out.println(booking);
		System.out.println(creditCard);
		System.out.println(email);
		System.out.println("********************************");
		
		
		 FlightInformation upflightData = arsService.viewFlightDetail(upflight);
		 
		 booking.setFlight(upflightData);
		 booking.setCreditCard(creditCard);
		 booking.setCustEmail(email);
		 booking.setNoOfAdult(adult);
		 booking.setNoOfChildren(child);
		 booking.setClassType(classType);
		 
		 if(classType.equals("first"))
		 {
			 double price =( adult + child ) * upflightData.getFirstSeatFare() ;
			 
			 booking.setTotalFare(price);
		 }
		 
		 else if(classType.equals("business"))
		 {
			 double price =( adult + child ) * upflightData.getBussSeatsFare() ;
			 
			 booking.setTotalFare(price);
		 }
		 
		 arsService.addBookingInformation(booking);
		 
		 
		 System.out.println("1 ."+booking.getBookingId());
		 if( downFlight !=0 )
		 {
			 FlightInformation downflightData = arsService.viewFlightDetail(downFlight);
			 booking.setFlight(downflightData);
			 
			
			 if(classType.equals("first"))
			 {
				 double price =( adult + child ) * downflightData.getFirstSeatFare() ;
				 
				 booking.setTotalFare(price);
			 }
			 
			 else if(classType.equals("business"))
			 {
				 double price =( adult + child ) * downflightData.getBussSeatsFare() ;
				 
				 booking.setTotalFare(price);
			 }
			 
			 
			 arsService.addBookingInformation(booking);
			 System.out.println("2 ."+booking.getBookingId());
		 }
		 
		 return null;
	}
	
	@RequestMapping( value="/viewAllFlights.do" )
	public ModelAndView viewAllFlights()
	{		
		
		List<FlightInformation> allFlights = arsService.showAllFlights();
		System.out.println(allFlights);
		if(allFlights.isEmpty())
		{
			ModelAndView model = new ModelAndView("error");
			model.addObject("errMsg","NO DATA TO DISPLAY");
			return model;
		}
		
		return new ModelAndView( "viewFlights", "flightData", allFlights );
	}
	

//	public String getRole(String uname, String pass);
//	public  HashMap<String, Airport> getAirportList();
//	public List <FlightInformation> showAllFlights();
//	
//	
//	/*
//	 * methods mainly for admin
//	 */
//	public void addFlightInformation(FlightInformation flightInfo);
//	public void updateFlightInformation(FlightInformation updateflight);
//	
//
//	/*
//	 * methods mainly for executive
//	 */
//	public FlightInformation viewFlightDetail(int flightNo);
//	public List<BookingInformation> viewBookings(int flightNo);
//	public BookingInformation getBooking(int bookId);
//	
//
//	/*
//	 * methods mainly for customer
//	 */
//	public List<FlightInformation> viewFlightOn(String depArp , String arrArp , Date date);
//	public int addBookingInformation(BookingInformation bookingEntry);
//	public void removeBooking(int bookId);
	
	
}
